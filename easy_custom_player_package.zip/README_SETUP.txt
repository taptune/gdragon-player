# Custom NFC Music Player Setup

## Where to put files

Put your song files in:

music/

Put your image files in:

images/

## What to edit

Open index.html and find:

EASY CUSTOM SETUP

Only edit the `PLAYER_CONFIG` section.

## Add a song

Copy this block inside `tracks`:

{
  title: "My Song",
  file: "music/my-song.mp3",
  images: [
    "images/my-cover-1.png",
    "images/my-cover-2.png"
  ]
}

Use commas between song blocks.

## Optional ALT MODE

ALT MODE is the double-tap mode.

Change these files:

altModeImages: [
  "images/alt-1.png",
  "images/alt-2.png"
]

Or set it to [] if you do not want separate alternate images.

## Legal note for selling

Do not include copyrighted songs, celebrity images, album covers, logos, or fan art unless you own the rights or have permission.

The safest commercial version is:
- no included music
- no included third-party images
- buyer uploads their own legal files
